let materialAtual = "";

// Função para mostrar a SearchBox com o texto do material correspondente
function mostrarCaixaBusca(material) {
    const input = document.getElementById('caixa-busca');
    input.placeholder = `Digite a quantidade de ${material} (kg)`; // Corrigido para template literal
    input.style.display = 'block';
    input.value = ""; // Limpa o valor anterior
    materialAtual = material; // Atualiza o material atual
}

// Função para atualizar a quantidade e esconder a SearchBox ao pressionar Enter
function atualizarQuantidade(event) {
    if (event.key === 'Enter') {
        const input = document.getElementById('caixa-busca');
        const quantidade = parseInt(input.value, 10); // Converte o valor para inteiro

        if (!isNaN(quantidade) && quantidade >= 0) {
            // Seleciona o elemento correspondente ao material
            const item = document.getElementById(`material-${materialAtual}`); // Corrigido para template literal
            if (item) {
                item.textContent = `${materialAtual}: ${quantidade} kg`; // Atualiza o texto
            } else {
                alert("Erro: Elemento correspondente ao material não encontrado.");
            }
        } else {
            alert("Por favor, insira um valor válido (número positivo).");
        }

        input.style.display = 'none'; // Esconde a SearchBox após registrar
    }
}
